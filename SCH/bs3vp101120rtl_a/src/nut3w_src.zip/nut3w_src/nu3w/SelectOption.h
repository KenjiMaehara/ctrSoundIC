#pragma once

struct SelectOption{
	unsigned m_mask;
};