/****************************************************************************
    BSch3V schematic capture
    Copyright (C) 1997-2005 H.Okada

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*****************************************************************************/

#pragma once


// CFindDlg �_�C�A���O

class CFindDlg : public CDialog
{
	DECLARE_DYNAMIC(CFindDlg)

public:
	CFindDlg(CWnd* pParent = NULL);   // �W���R���X�g���N�^
	virtual ~CFindDlg();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_FIND };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:

	BOOL m_bFindComment;
	BOOL m_bFindLabel;
	BOOL m_bFindName;
	BOOL m_bFindNameLib;
	BOOL m_bFindManufacture;
	BOOL m_bFindManufacturePartNumber;
	BOOL m_bFindPackage;
	BOOL m_bFindNote;

	BOOL m_bFindNum;
	BOOL m_bFindTag;
	BOOL m_bMatchWhole;
	BOOL m_bCaseSensitive;
	CString m_strFind;
//	afx_msg void OnBnClickedFindManufacturepn();
};
