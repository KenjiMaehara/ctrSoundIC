/****************************************************************************
    LCoV library editor for BSch3V
    Copyright (C) 2004-2005 H.Okada (http://www.suigyodo.com/online)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*****************************************************************************/

#pragma once


// CCompProperty �_�C�A���O

class CCompProperty : public CDialog
{
	DECLARE_DYNAMIC(CCompProperty)

public:
	CCompProperty(CWnd* pParent = NULL);   // �W���R���X�g���N�^
	virtual ~CCompProperty();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_DLG_PROP_COMP };

	CString m_name;
	CString m_num;
	int m_block;
	int m_x;
	int m_y;
	BOOL m_usePtn;
	BOOL m_noBitPtn;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
protected:
	virtual void OnOK();
	BOOL isValidPartName(const char* psz);
public:
	CString m_note;
	CString m_mfr;
	CString m_mfrpn;
	CString m_pkg;

//	afx_msg void OnEnChangeEditNote();
	afx_msg void OnBnClickedCheckUseptn();
};
