/****************************************************************************
    LCoV library editor for BSch3V
    Copyright (C) 2004-2005 H.Okada (http://www.suigyodo.com/online)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*****************************************************************************/

#ifndef COORD2_H
#define COORD2_H

CSize SSize2CSize(const SSize& ssize);
SSize CSize2SSize(const CSize& csize);

CPoint SPoint2CPoint(const SPoint& spoint);
SPoint CPoint2SPoint(const CPoint& cpoint);

CRect SRect2CRect(const SRect& srect);
SRect CRect2SRect(const CRect& crect);

//�������ʂɓ_���w�苗�����ɂ��邩�ǂ����̔���
bool PointIsCloseToLineSide(const SPoint& ptPoint,const SPoint& ptLineBegin,const SPoint& ptLineEnd,int limit, SPoint& ptCross);

#endif