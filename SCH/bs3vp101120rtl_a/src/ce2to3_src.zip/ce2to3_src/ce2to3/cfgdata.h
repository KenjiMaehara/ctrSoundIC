// Copyright (C) 2002 H.Okada(suigyodo) All rights reserved.
#ifndef CFGDATA_H
#define CFGDATA_H

//#include <qlist.h>
//#include <string.h>
#include <stdio.h>
#include <list>
#include <string>
using namespace std;

//�ݒ�f�[�^�̓��o�͂��s��
class SCfgDataElm{
public:
	string group;
	string	key;
	string	data;
	SCfgDataElm(){}
	~SCfgDataElm(){}
};	


typedef list<SCfgDataElm*> SCfgList;
typedef list<SCfgDataElm*>::iterator SCfgListIte;

class SCfgData{
protected:
	SCfgList listCfgData;
	void clear();
	SCfgDataElm* findExisting(const string& sGroup,const string& sKey);

public:
	SCfgData();
	~SCfgData();
	bool load(const char* filename);
	bool save(const char* filename);
	void setString(const string& sGroup,const string& sKey,const string& sData);
	void setInt(const string& sGroup,const string& sKey,int data);
	bool getString(const string& sGroup,const string& sKey,string& sData);
	bool getInt(const string& sGroup,const string& sKey,int& data);
	//void dump();
};
#endif