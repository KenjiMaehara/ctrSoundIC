// Copyright (C) 2002 H.Okada(suigyodo) All rights reserved.
/****************************************************************************
** XBSch�}�ʗv�f���i�N���X
****************************************************************************/
#include "stdafx.h"
#include <stdio.h>
#include <assert.h>
#include <list>
#include <string>
using namespace std;
#include "ce3io.h"
#include "xbschglobal.h"
#include "xbschobj.h"
#include "xbschcomponent.h"

//�R���X�g���N�^
SXBSchComponent::SXBSchComponent()
{
	m_name		= "";				//���O
	m_refnum	= "";				//�Q�Ɣԍ�
	m_block		= 0;				//�u���b�N�ԍ�
	m_dir		= COMPONENT_DIR_0;	//����
	m_compInfoIndex = NULL;			//���i�̏��ւ̃|�C���^
	m_pinltrb	=0;					//LTRB�Ƀs�������݂��Ă��邩�ǂ����̃t���O
	m_orgname	= "";				//�璷�����ǁA���C�u��������ǂݑ��˂����i���c�����߂̂���
	resetRefnumPos();
	resetNamePos();
}

//�������s��
SXBSchObj* SXBSchComponent::duplicate()
{
	SXBSchComponent* pComp = new SXBSchComponent(*this);
	SXBSchObj* newObj = pComp;
	return newObj;
}

//m_dir�ϐ������E���]����
void SXBSchComponent::mirrorDir()
{
	assert(m_dir>=0 && m_dir<=7);
	m_dir &=0x07;	//���ɈӖ��i�V
	m_dir ^=0x04;	//���]�t���O�̔��]
	int pinL = (m_pinltrb & COMPONENT_HASLPIN);
	int pinR = (m_pinltrb & COMPONENT_HASRPIN);
	m_pinltrb &= (COMPONENT_HASTPIN | COMPONENT_HASBPIN);
	if(pinL)  m_pinltrb |= COMPONENT_HASRPIN;
	if(pinR)  m_pinltrb |= COMPONENT_HASLPIN;
}

//m_dir�ϐ����E��]����
void SXBSchComponent::rotateDir()
{
	assert(m_dir>=0 && m_dir<=7);
	m_dir &=0x07;	//���ɈӖ��i�V
	if(m_dir & 0x04){
		m_dir -=1;
		m_dir |= 0x04;
	}else{
		m_dir +=1;
		m_dir &= 0x03;
	}
	m_pinltrb <<= 1;
	if(m_pinltrb & 0x10){
		m_pinltrb |= 1;
	}
	m_pinltrb &= 0xf;
}


//�Q�Ɣԍ��̈ʒu���f�t�H���g�̈ʒu�ɕύX
void SXBSchComponent::resetRefnumPos()
{
	m_refnum_pos = SPoint(COMPONENT_DEFAULT_REFNUM_X,COMPONENT_DEFAULT_REFNUM_Y);
}

//���i���̈ʒu���f�t�H���g�̈ʒu�ɕύX
void SXBSchComponent::resetNamePos()
{
	m_name_pos = SPoint(COMPONENT_DEFAULT_NAME_X,COMPONENT_DEFAULT_NAME_Y);
}

//�ʒu�𓮂���
void SXBSchComponent::move(int offsetx,int offsety)
{
	SPoint p(offsetx,offsety);
	m_p1 += p;
}	




//X���W���w�肵�č��E���]���s��
void SXBSchComponent::mirrorH(int x)
{
	int componentcenter;
	int componentwidth;
	if(m_compInfoIndex != NULL){
		componentwidth = size().w(); 
//		componentwidth = (m_compInfoIndex->size().w()*10); 
	}else{
		componentwidth = 20;
	}

	componentcenter = -componentwidth/2;


	int textcenter;	//�����񐅕������̈ʒu�̕��i��������̈ʒu�B
	int textX;

	textcenter = m_name_pos.x() + m_name.length()*8/2 - componentcenter;	//���݈ʒu
	textcenter = -textcenter;	//���E���]�����ʒu
	textX = textcenter - m_name.length()*8/2 + componentcenter;
	m_name_pos.setX(textX);


	textcenter = m_refnum_pos.x() + m_refnum.length()*8/2 - componentcenter;	//���݈ʒu
	textcenter = -textcenter;	//���E���]�����ʒu
	textX = textcenter - m_refnum.length()*8/2 + componentcenter;
	m_refnum_pos.setX(textX);

	componentcenter = m_p1.x() + componentcenter;
	componentcenter = x-(componentcenter-x);
	m_p1.setX(componentcenter + componentwidth/2);
	
	mirrorDir();
}

//���E���]���s��
void  SXBSchComponent::mirrorH()
{
	int componentHWidth;
	if(m_compInfoIndex != NULL){
		componentHWidth = size().w(); 
//		componentHWidth = m_compInfoIndex->size().w()*10; 
	}else{
		componentHWidth = 20;
	}
	int x = m_p1.x() - componentHWidth / 2;
	mirrorH(x);
}


SSize SXBSchComponent::size() const
{
	int w;
	int h;
	if(m_compInfoIndex == NULL){
		w=20; h=20;
	}else{
		w = m_compInfoIndex->size().w()*10;
		h = m_compInfoIndex->size().h()*10;
		if(m_dir & 1){	//���T�C�Y�Əc�T�C�Y������ւ��
			int n=w; w=h; h=n;
		}
	}
	return SSize(w,h);
}

//��L�͈͂�Ԃ�
SRect SXBSchComponent::area()
{
	SSize sizeComp = size();
	int r = m_p1.x();
	int b = m_p1.y();
	int l = r - sizeComp.w();
	int t = b - sizeComp.h();
	if(m_pinltrb & COMPONENT_HASLPIN) l -= PIN_LENGTH;
	if(m_pinltrb & COMPONENT_HASTPIN) t -= PIN_LENGTH;
	if(m_pinltrb & COMPONENT_HASRPIN) r += PIN_LENGTH;
	if(m_pinltrb & COMPONENT_HASBPIN) b += PIN_LENGTH;
	
	return SRect(SPoint(l,t),SPoint(r,b));
}

//��L�͈͂�Ԃ�
SRect SXBSchComponent::bodyArea()
{
	SSize sizeComp = size();
	int w = sizeComp.w();
	int h = sizeComp.h();
	return SRect(m_p1.x()-w,m_p1.y()-h,w,h);
}



//���i���̐�L�͈͂�Ԃ�
SRect SXBSchComponent::nameArea() const 
{
	int w = m_name.length()*8;
	int h = 10;
	return SRect(m_p1.x()+m_name_pos.x(),m_p1.y()+m_name_pos.y()-h,w,h);
}

//�Q�Ɣԍ��̐�L�͈͂�Ԃ�
SRect SXBSchComponent::refnumArea() const
{
	int w = m_refnum.length()*8;
	int h = 10;
	return SRect(m_p1.x()+m_refnum_pos.x(),m_p1.y()+m_refnum_pos.y()-h,w,h);
}


//XY���S���W���w�肵�āA��]���s��
void SXBSchComponent::rotate(const SPoint& p)
{
	resetRefnumPos();
	resetNamePos();
	SPoint center = bodyArea().center();
	int centerY = p.y() + (center.x() - p.x()) ;
	int centerX = p.x() - (center.y() - p.y()) ;
	rotateDir();
	SSize sizeComp = size();
	int x = centerX + sizeComp.w()/2;
	int y = centerY + sizeComp.h()/2;
	m_p1.setX(x);
	m_p1.setY(y);
}

//��]���s��
void  SXBSchComponent::rotate()
{
	resetRefnumPos();
	resetNamePos();
	rotateDir();
	//	rotate(bodyArea().center());
}

SRect SXBSchComponent::rotateRect()
{
	return bodyArea();
}


//�͈͂��w�肵�đI�����s��
unsigned SXBSchComponent::testSelection(const SRect& rc)
{
	if( rc.intersect(bodyArea()) ){
		return SELECT_ALL;
	}else{
		return 0;
	}
}


//�͈͂�I�����ăh���b�O�I�����s��
unsigned SXBSchComponent::testSelectionForDrag(const SRect& rc)
{
	if( rc.intersect(bodyArea()) ){
		return SELECT_ALL;
	}else{
		return 0;
	}
}

//�_���w�肵�đI���d�v�x��Ԃ�
int SXBSchComponent::qSelectWeight(const SPoint& p)
{
	int n;
	int nMax=0;
	int nOnFlag=0;
	n = PointAndRectMag(p,bodyArea());
	if(n){
		nOnFlag |= ON_OBJ;
		if(n>nMax) nMax = n;
	}
	n = PointAndRectMag(p,nameArea());
	if(n){
		nOnFlag |= ON_NAME;
		if(n>nMax) nMax = n;
	}
	n = PointAndRectMag(p,refnumArea());
	if(n){
		nOnFlag |= ON_NUM;
		if(n>nMax) nMax = n;
	}
	return nMax|nOnFlag;
}

void SXBSchComponent::setName(const char* psz)
{
	m_name = psz;
}

void SXBSchComponent::setOrgName(const char* psz)
{
	m_orgname = psz;
}


void SXBSchComponent::moveNamePos(int offsetx,int offsety)
{
	m_name_pos.setX(m_name_pos.x()+offsetx);
	m_name_pos.setY(m_name_pos.y()+offsety);
}

void SXBSchComponent::setRefnum(const char* psz)
{
	m_refnum = psz;
}

void SXBSchComponent::moveRefnumPos(int offsetx,int offsety)
{
	m_refnum_pos.setX(m_refnum_pos.x()+offsetx);
	m_refnum_pos.setY(m_refnum_pos.y()+offsety);
}

void SXBSchComponent::setBlock(int n)
{
//	int blockCount;
//	if(m_compInfoIndex != NULL){
//		blockCount = m_compInfoIndex->block(); 
//	}else{
//		blockCount = 1;
//	}
//	if(n >= blockCount || n<0) return;
//	else 
		m_block = n;
}


void SXBSchComponent::setDir(int n)
{
	n &= 7;
	m_dir = n;
}

//X:nnn,Y:nnn,LIB:cccc,DIR:n,BLK:n,N:cccc,NX:nnn,NY:nnn,R:cccc,RX:nnn,RY:nnn,
bool SXBSchComponent::readCe3(SReadCE3& rce3,const SPoint* pptOrigin,SXBSchDoc*)
{
	string str;
	bool bInitX1 = false;
	bool bInitY1 = false;
	bool bInitLib = false;

	while(1){
		if(rce3.ReadRecord(str)==EOF) return false;
		if(str[0] == '-'){
			if( (str != "-COMPONENT") || !bInitX1 || !bInitY1 || !bInitLib){
				return false;
			}else{
				break;	//break while(1){ }
			}
		}else if(str[0] == '+'){
			str[0]='-';
			if(rce3.SkipTo(str)==EOF) return false;
		}else{
			int n;
			int l=str.length();
			for(n=0;n<l;n++){
				if(str[n]==':') break;
			}
			if(0<n && n<l){	// : �ŕ�����ꂽ���R�[�h�ł���
				string var = str.substr(0,n);				//�擪����:�̎�O�܂�
				string val = str.substr(n+1);
				int nVal;
				if(var=="X"){
					nVal = atoi(val.c_str());
					if(pptOrigin) nVal += pptOrigin->x();		
					m_p1.setX(nVal);
					bInitX1 = true;
				}else
				if(var=="Y"){
					nVal = atoi(val.c_str());
					if(pptOrigin) nVal += pptOrigin->y();		
					m_p1.setY(nVal);
					bInitY1 = true;
				}else
				if(var=="LIB"){
					m_orgname=val;
					bInitLib = true;
					m_compInfoIndex = g_SearchComponentIndex(val.c_str(),NULL,NULL,NULL);
				}else
				if(var=="DIR"){
					nVal = atoi(val.c_str());
					if(nVal>=0 && nVal <8){
						m_dir = nVal;
					}
				}else
				if(var=="BLK"){
					if(m_compInfoIndex == NULL){
						m_block = 0;
					}else{
						nVal = atoi(val.c_str());
						if(nVal>=0 && nVal < m_compInfoIndex->block()){
							m_block = nVal;
						}else{
							m_block = 0;
						}
					}
				}else
				if(var=="N"){
					m_name=val;
				}else
				if(var=="NX"){
					nVal = atoi(val.c_str());
					m_name_pos.setX(nVal);
				}else
				if(var=="NY"){
					nVal = atoi(val.c_str());
					m_name_pos.setY(nVal);
				}else
				if(var=="R"){
					m_refnum=val;
				}else
				if(var=="RX"){
					nVal = atoi(val.c_str());
					m_refnum_pos.setX(nVal);
				}else
				if(var=="RY"){
					nVal = atoi(val.c_str());
					m_refnum_pos.setY(nVal);
				}
			}
		}
	}
	setPinLtrb();
	return true;
}


bool SXBSchComponent::writeCe3(SWriteCE3& wce3,const SPoint* pptOrigin)
{
	char sz[32];

	int x = m_p1.x();
	int y = m_p1.y();

	string str;

	if(pptOrigin){
		x -= pptOrigin->x();
		y -= pptOrigin->y();
	}

	wce3.WriteRecord("+COMPONENT");
	wce3.WriteRecordInt("L",m_Layer);

	sprintf(sz,"X:%d",x);
	wce3.WriteRecord(sz);

	sprintf(sz,"Y:%d",y);
	wce3.WriteRecord(sz);

	str = "LIB:";
	str += m_orgname;
	wce3.WriteRecord(str);

	sprintf(sz,"DIR:%d",m_dir);
	wce3.WriteRecord(sz);

	sprintf(sz,"BLK:%d",m_block);
	wce3.WriteRecord(sz);


	str = "N:";
	str += m_name;
	wce3.WriteRecord(str);

	sprintf(sz,"NX:%d",m_name_pos.x());
	wce3.WriteRecord(sz);

	sprintf(sz,"NY:%d",m_name_pos.y());
	wce3.WriteRecord(sz);

	str = "R:";
	str += m_refnum;
	wce3.WriteRecord(str);

	sprintf(sz,"RX:%d",m_refnum_pos.x());
	wce3.WriteRecord(sz);

	sprintf(sz,"RY:%d",m_refnum_pos.y());
	wce3.WriteRecord(sz);

	wce3.WriteRecord("-COMPONENT");
	wce3.WriteEOL();
	return true;
}


void SXBSchComponent::setCompInfoIndex(const SCompIndex* pIndex)
{
	if(pIndex == NULL)return;
	m_compInfoIndex = pIndex;
	if(m_block >= m_compInfoIndex->block()){
		m_block = 0;
	}
	m_orgname = m_compInfoIndex->name();
	setPinLtrb();
}
	
//LTRB�Ƀs�������݂��Ă��邩�ǂ����̃t���O�̐ݒ�
void SXBSchComponent::setPinLtrb()
{
	SPoint pt;	//�_�~�[
	int ltrb;
	if(m_compInfoIndex == NULL){
		m_pinltrb=0;
		return;
	}
	int nMax = m_compInfoIndex->pinCount();
	for(int nIndex = 0;nIndex < nMax;nIndex++){
		pinEnd(nIndex,ltrb,pt);
		m_pinltrb |= ((1<<ltrb)&0xf);
	}
}

//n�Ԗڂ̃s���̈ʒu�𓾂�B
SPoint SXBSchComponent::pinPosition(int nIndex)const
{
	SPoint pt;
	int dummy;
	pinEnd(nIndex,dummy,pt);
	return pt;
}

int SXBSchComponent::pinCount() const
{
	if(m_compInfoIndex == NULL){
		return 0;
	}else{
		return m_compInfoIndex->pinCount();
	}
}


//�s���̈ʒu�����擾����
const SPin* SXBSchComponent::pinEnd(int nIndex,int& nLtrb,SPoint& ptEnd) const
{
	if(m_compInfoIndex == NULL){
		return NULL;
	}
	const SPin* pininfo =  m_compInfoIndex->pin(nIndex);
	if(pininfo == NULL){
		return NULL;
	}
	int ltrb = pininfo->ltrb(); // L:0 T:1 R:2 B:3
	int offset = pininfo->offset()*10;

	nLtrb = (ltrb + (m_dir & 3)) &3;
	if(m_dir & 4){
		if(nLtrb==0){
			nLtrb = 2;
		}else if(nLtrb==2){
			nLtrb = 0;
		}
	}
	SSize wh = size();
	int w = wh.w();
	int h = wh.h();
	int x = m_p1.x();
	int y = m_p1.y();
	switch(nLtrb){
	case 0:		// L
		ptEnd.setX(x-w-PIN_LENGTH);
		if(m_dir == 2 || m_dir == 3 || m_dir == 6 || m_dir == 7){
			ptEnd.setY(y-offset);
		}else{
			ptEnd.setY(y-h+offset);
		}
		break;
	case 1:		// T
		ptEnd.setY(y-h-PIN_LENGTH);
		if(m_dir == 1 || m_dir == 2 || m_dir == 4 || m_dir == 7){
			ptEnd.setX(x-offset);
		}else{
			ptEnd.setX(x-w+offset);
		}
		break;
	case 2:		// R
		ptEnd.setX(x+PIN_LENGTH);
		if(m_dir == 2 || m_dir == 3 || m_dir == 6 || m_dir == 7){
			ptEnd.setY(y-offset);
		}else{
			ptEnd.setY(y-h+offset);
		}
		break;
	case 3:		// B
		ptEnd.setY(y+PIN_LENGTH);
		if(m_dir == 1 || m_dir == 2 || m_dir == 4 || m_dir == 7){
			ptEnd.setX(x-offset);
		}else{
			ptEnd.setX(x-w+offset);
		}
		break;
	}
	return pininfo;	
}