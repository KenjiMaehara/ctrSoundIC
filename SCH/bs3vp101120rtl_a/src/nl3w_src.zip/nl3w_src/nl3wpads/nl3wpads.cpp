// nl3wpads.cpp : DLL �A�v���P�[�V�����p�ɃG�N�X�|�[�g�����֐����`���܂��B
//

#include "stdafx.h"
#include <stdio.h>
#include "dlliftype.h"


void __stdcall typeName(char* buff,int buffsize)
{
	static const char* fmtname = "PADS";	
	strncpy(buff,fmtname,buffsize-1);
	buff[buffsize-1] = '\0';
}


/////////////////////////////////////////////////////////////////////////////////////
//ERROR CODE
//successful: 0
//file error: -1
//no net data: -2
//user define error: =>1
int __stdcall fnWriteNetList(const char* filename, const SExportNetlistInfo* pNetInfo)
{
	if(filename == NULL) return -1;
	FILE* fp = fopen(filename,"wt");
	if(fp==NULL) return -1;

	if(pNetInfo==NULL) return -2;


	fprintf(fp,"*PADS-PCB*\n");
	fprintf(fp,"*PART*\n");

	for(int i=0;i<pNetInfo->nComponentInfoCount;i++){
		fprintf(fp,"%s%d %s\n",
			pNetInfo->array_CompInfo[i].pszPrefix,
			pNetInfo->array_CompInfo[i].nSuffix,
			pNetInfo->array_CompInfo[i].pszPackage
		);
	}

	fprintf(fp,"*NET*\n");
	
	for(int i=0;i<pNetInfo->nNetValueCount;i++){
		fprintf(fp,"*SIGNAL* %s\n",pNetInfo->array_NetValue[i].pszNetName);
		int n=0;
		for(int j=0;j< pNetInfo->array_NetValue[i].nPinCount; j++){
			if(n>0){
				fprintf(fp,"  ");
			}
			fprintf(fp,"%s.%s",
				pNetInfo->array_NetValue[i].pArrayPinValue[j].pszRefNum,
				pNetInfo->array_NetValue[i].pArrayPinValue[j].pszPinNum);
			n++;

			if(n==5){
				fprintf(fp,"\n");
				n=0;
			}

		}
		if(n>0){
			fprintf(fp,"\n");
		}

	}
	fprintf(fp,"*END*\n");
	fclose(fp);
	return 0;
}



