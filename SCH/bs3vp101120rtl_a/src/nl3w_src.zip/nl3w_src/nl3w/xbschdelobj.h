/****************************************************************************
    BSch3V schematic capture
    Copyright (C) 1997-2005 H.Okada

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*****************************************************************************/

/****************************************************************************
** XBSch�}�ʗv�f�폜�I�u�W�F�N�g�N���X
****************************************************************************/
#ifndef XBSCHDELOBJ_H
#define XBSCHDELOBJ_H

#include "xbsch.h"
#include "xbschobj.h"

//class SXBSchDelObj:public SXBSchObj
//{
//public:
//	//�R���X�g���N�^
//	SXBSchDelObj(){};
//	//SXBSchJunc(const SXBSchJunc& junc);	//�R�s�[�R���X�g���N�^
//	//�f�X�g���N�^
//	virtual ~SXBSchDelObj(){};
//	//ID�̎擾
//	virtual unsigned id(){return ID_DELETEOBJ;}
//	unsigned objectFilterValue(){return 0;} 
//};

#endif
