//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by nlist.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_NLIST_DIALOG                102
#define IDS_DSTOPENERR                  102
#define IDS_SRCOPENERR                  103
#define IDS_FINISHED                    104
#define IDS_ADD_ADDIN                   105
#define IDS_ADDIN_INDEX_ERROR           106
#define IDS_NO_NETINFO                  107
#define IDS_VERSION                     108
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDI_SMALL                       129
#define IDD_DIALOG_SETADDIN             131
#define IDC_LIST_SRC                    1001
#define IDC_REFSRC                      1002
#define IDC_EDIT_DST                    1003
#define IDC_REFDST                      1004
#define IDC_CLR                         1005
#define IDC_EDIT_RPT                    1006
#define IDC_CHECK1                      1007
#define IDC_CHECK_NC                    1007
#define IDC_REFRPT                      1008
#define IDC_RADIO2                      1010
#define IDC_BUTTON_UP                   1010
#define IDC_BUTTON_DOWN                 1011
#define IDC_BUTTON_SETADDIN             1011
#define IDC_BUTTON_ADD                  1012
#define IDC_BUTTON_REMOVE               1013
#define IDC_LIST_FILES                  1014
#define IDC_COMBO_NETTYPE               1015
#define IDC_STATIC_VERSION              1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
